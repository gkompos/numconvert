package net.codeproject;

import java.util.List;

public interface DataDAO {
	public int insertData(Data c);
	public String decocthex(String num,String uname);
}
